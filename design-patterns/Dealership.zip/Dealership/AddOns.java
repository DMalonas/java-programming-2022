public abstract class AddOns {
     protected double price;

     public double getPrice(){
          return this.price;
     }

     public abstract String getName();


}

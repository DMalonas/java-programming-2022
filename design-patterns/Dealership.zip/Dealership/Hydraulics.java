public class Hydraulics extends AddOns {

    Hydraulics(){
        price = -20;
    }

    @Override
    public String getName(){
        return "Hydraulics";
    }


}

public class SpinnerRims extends AddOns {
    SpinnerRims(){
        price = 1337.23;
    }
    @Override
    public String getName(){
        return "Spinner Rims";
    }
}

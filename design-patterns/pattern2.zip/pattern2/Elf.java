public class Elf extends Character {
    public Elf(String name) {
        this.name = name;
        this.strength = 4;
        this.resilience = 2;
    }
}

public class SunRoof extends AddOns {

    public SunRoof(){
        price = 279.82;
    }

    @Override
    public String getName(){
        return "Sun Roof";
    }

}

public class FuzzyDice extends AddOns {
    FuzzyDice(){
        price = 8000.00;
    }

    @Override
    public String getName(){
        return "Fuzzy Dice";
    }

}

public class Customer {

    String name;
    String phone;

    Customer(String name, String phone){
        this.name = name;
        this.phone = phone;
    }


}

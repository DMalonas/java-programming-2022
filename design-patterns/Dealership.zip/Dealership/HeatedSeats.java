public class HeatedSeats  extends AddOns {


    public HeatedSeats(){
        price = 789.20;
    }

    @Override
    public String getName(){
        return "Heated Seats";
    }

}
